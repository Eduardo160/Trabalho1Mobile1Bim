package com.example.trabacadm1;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText edNome;
    private EditText edEmail;
    private EditText edIdade;
    private EditText edDisciplina;
    private EditText edNota1;
    private EditText edNota2;
    private Button btExibirResult;
    private Button btLimpar;
    private TextView tvErro;
    private TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edNome = findViewById(R.id.edNome);
        edEmail = findViewById(R.id.edEmail);
        edIdade = findViewById(R.id.edIdade);
        edDisciplina = findViewById(R.id.edDisciplina);
        edNota1 = findViewById(R.id.edNota1);
        edNota2 = findViewById(R.id.edNota2);
        btExibirResult = findViewById(R.id.btExibirResult);
        btLimpar = findViewById(R.id.btLimpar);
        tvErro = findViewById(R.id.tvErro);
        tvResultado = findViewById(R.id.tvResultado);

        btExibirResult.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                validarFormulario();
            }
        });

        // Ação para o botão "Limpar"
        btLimpar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                limparFormulario();
            }
        });
    }

    private void validarFormulario() {
        // Limpar mensagens anteriores
        tvErro.setText("");

        // Pegar valores digitados
        String nome = edNome.getText().toString();
        String email = edEmail.getText().toString();
        String idadeStr = edIdade.getText().toString();
        String disciplina = edDisciplina.getText().toString();
        String nota1Str = edNota1.getText().toString();
        String nota2Str = edNota2.getText().toString();

        // Verificar se todos os campos foram preenchidos corretamente
        if (TextUtils.isEmpty(nome)) {
            tvErro.setText("O campo de nome está vazio");
            return;
        }

        if (!email.contains("@")) {
            tvErro.setText("O email é inválido");
            return;
        }

        int idade;
        try {
            idade = Integer.parseInt(idadeStr);
            if (idade <= 0) {
                tvErro.setText("A idade deve ser um número positivo");
                return;
            }
        } catch (NumberFormatException e) {
            tvErro.setText("A idade deve ser numérica");
            return;
        }

        float nota1, nota2;
        try {
            nota1 = Float.parseFloat(nota1Str);
            nota2 = Float.parseFloat(nota2Str);

            if (nota1 < 0 || nota1 > 10 || nota2 < 0 || nota2 > 10) {
                tvErro.setText("As notas devem estar entre 0 e 10");
                return;
            }
        } catch (NumberFormatException e) {
            tvErro.setText("As notas devem ser numéricas");
            return;
        }

        // Calcular a média e determinar o status de aprovação
        float media = (nota1 + nota2) / 2;
        String status = media >= 6 ? "Aprovado" : "Reprovado";

        // Criar o resultado formatado
        String resultado = "Nome: " + nome + "\nEmail: " + email + "\nIdade: " + idade +
                "\nDisciplina: " + disciplina + "\nNota 1: " + nota1 + "\nNota 2: " + nota2 +
                "\nMédia: " + media + "\nStatus: " + status + "\n";

        // Pegar o que já está no TextView e adicionar o novo resultado
        String historicoAnterior = tvResultado.getText().toString();
        tvResultado.setText(historicoAnterior + resultado + "\n-----------------\n");

        // Limpar campos para próximo envio
        limparCampos();
    }

    private void limparFormulario() {
        edNome.setText("");
        edEmail.setText("");
        edIdade.setText("");
        edDisciplina.setText("");
        edNota1.setText("");
        edNota2.setText("");
        tvErro.setText("");
        tvResultado.setText("");
    }

    private void limparCampos() {
        // Limpa apenas os campos do formulário, mantendo o histórico
        edNome.setText("");
        edEmail.setText("");
        edIdade.setText("");
        edDisciplina.setText("");
        edNota1.setText("");
        edNota2.setText("");
    }
}